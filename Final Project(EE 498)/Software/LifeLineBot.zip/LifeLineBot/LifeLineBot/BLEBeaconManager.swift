//
//  BLEBeaconManager.swift
//  LifeLineBot
//
//  Created by Torryana Tanis
//  Function: Broadcasts BLE beacon so robot can track iPhone location

import Foundation
import CoreBluetooth
import Combine

/// Manages BLE advertising to broadcast the iPhone's location to the robot.
/// Advertising is triggered when SOS is activated, allowing the robot to range the iPhone's signal.
final class BLEBeaconManager: NSObject, ObservableObject {

    static let shared = BLEBeaconManager()

    // SOS service UUID - robot scans for this specific UUID
    static let serviceUUID = CBUUID(string: "A1B2C3D4-E5F6-7890-ABCD-EF1234567890")

    // Characteristic UUID for device identification
    static let characteristicUUID = CBUUID(string: "A1B2C3D4-E5F6-7890-ABCD-EF1234567891")

    private var peripheralManager: CBPeripheralManager?
    private var service: CBMutableService?
    private var characteristic: CBMutableCharacteristic?
    private var serviceAdded = false
    private var shouldAdvertiseWhenReady = false

    @Published var isAdvertising = false
    @Published var bluetoothState: CBManagerState = .unknown

    private override init() {
        super.init()
    }

    /// Initialize the peripheral manager (call early, e.g., at app launch)
    func initialize() {
        guard peripheralManager == nil else { return }
        print("BLE: Initializing peripheral manager...")
        peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
    }

    /// Start SOS advertising so the robot can detect and range the iPhone
    func startSOSAdvertising() {
        // Initialize manager if needed
        if peripheralManager == nil {
            print("BLE: Initializing peripheral manager for SOS...")
            shouldAdvertiseWhenReady = true
            peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
            return
        }

        guard let manager = peripheralManager,
              manager.state == .poweredOn else {
            print("BLE: Cannot advertise - Bluetooth not powered on, will start when ready")
            shouldAdvertiseWhenReady = true
            return
        }

        guard !manager.isAdvertising else {
            print("BLE: Already advertising for SOS")
            return
        }

        // Set up the service if not already done
        if !serviceAdded {
            setupService()
        }

        // Advertisement data with SOS identifier
        let advertisementData: [String: Any] = [
            CBAdvertisementDataServiceUUIDsKey: [BLEBeaconManager.serviceUUID],
            CBAdvertisementDataLocalNameKey: "SOS"
        ]

        manager.startAdvertising(advertisementData)
        print("BLE: Started SOS advertising with UUID: \(BLEBeaconManager.serviceUUID.uuidString)")
    }

    /// Stop SOS advertising
    func stopSOSAdvertising() {
        shouldAdvertiseWhenReady = false

        guard let manager = peripheralManager else { return }

        if manager.isAdvertising {
            manager.stopAdvertising()
            print("BLE: Stopped SOS advertising")
        }

        DispatchQueue.main.async {
            self.isAdvertising = false
        }
    }

    /// Set up the GATT service and characteristic
    private func setupService() {
        guard let manager = peripheralManager, !serviceAdded else { return }

        // Create a characteristic that identifies this device as SOS source
        characteristic = CBMutableCharacteristic(
            type: BLEBeaconManager.characteristicUUID,
            properties: [.read],
            value: "SOS-iPhone".data(using: .utf8),
            permissions: [.readable]
        )

        // Create the service
        service = CBMutableService(type: BLEBeaconManager.serviceUUID, primary: true)
        service?.characteristics = [characteristic!]

        // Add service to peripheral manager
        manager.add(service!)
        print("BLE: SOS service added")
    }
}

// MARK: - CBPeripheralManagerDelegate
extension BLEBeaconManager: CBPeripheralManagerDelegate {

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        DispatchQueue.main.async {
            self.bluetoothState = peripheral.state
        }

        switch peripheral.state {
        case .poweredOn:
            print("BLE: Bluetooth is powered on")
            // Only start advertising if SOS was triggered
            if shouldAdvertiseWhenReady {
                startSOSAdvertising()
            }

        case .poweredOff:
            print("BLE: Bluetooth is powered off")
            DispatchQueue.main.async {
                self.isAdvertising = false
            }

        case .unauthorized:
            print("BLE: Bluetooth unauthorized - check permissions")

        case .unsupported:
            print("BLE: Bluetooth not supported on this device")

        case .resetting:
            print("BLE: Bluetooth is resetting")

        case .unknown:
            print("BLE: Bluetooth state unknown")

        @unknown default:
            print("BLE: Unknown Bluetooth state")
        }
    }

    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        DispatchQueue.main.async {
            if let error = error {
                print("BLE: Failed to start SOS advertising - \(error.localizedDescription)")
                self.isAdvertising = false
            } else {
                print("BLE: Successfully started SOS advertising - robot can now detect iPhone")
                self.isAdvertising = true
            }
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        if let error = error {
            print("BLE: Failed to add service - \(error.localizedDescription)")
            serviceAdded = false
        } else {
            print("BLE: SOS service added successfully")
            serviceAdded = true
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        // Respond to read requests from the robot
        if request.characteristic.uuid == BLEBeaconManager.characteristicUUID {
            if let value = characteristic?.value {
                request.value = value
                peripheral.respond(to: request, withResult: .success)
                print("BLE: Responded to read request")
            } else {
                peripheral.respond(to: request, withResult: .attributeNotFound)
            }
        }
    }
}
