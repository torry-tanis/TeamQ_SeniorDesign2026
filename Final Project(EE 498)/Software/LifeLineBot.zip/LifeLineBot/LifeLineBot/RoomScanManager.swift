//
//  RoomScanManager.swift
//  Created by Torryana Tanis
//  Function: Manages room mapping using the robot's LiDAR sensor on the Pi
//

import Foundation
import Combine
import UIKit

/// Server URL for Pi communication (same as watch app)
private let serverBaseURL = "http://100.95.21.127:5000"

/// Manages room mapping using the robot's onboard LiDAR
final class RoomScanManager: ObservableObject {

    static let shared = RoomScanManager()

    // MARK: - Published State

    @Published var isMapping = false
    @Published var mappingProgress: Float = 0.0
    @Published var statusMessage = "Ready to map"
    @Published var errorMessage: String?

    // MARK: - UserDefaults Keys

    private let scanCompletedKeyPrefix = "hasCompletedRoomScan_"
    private let lastScanDateKeyPrefix = "lastRoomScanDate_"

    // MARK: - Initialization

    private init() { }

    // MARK: - Robot LiDAR Mapping

    /// Send command to Pi to start LiDAR
    func startRobotMapping(completion: @escaping (Result<Void, Error>) -> Void) {
        isMapping = true
        statusMessage = "Starting LiDAR..."
        errorMessage = nil

        guard let url = URL(string: "\(serverBaseURL)/start-lidar") else {
            isMapping = false
            completion(.failure(ScanError.invalidURL))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 30

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isMapping = false

                if let error = error {
                    self?.errorMessage = error.localizedDescription
                    self?.statusMessage = "LiDAR start failed"
                    completion(.failure(error))
                    return
                }

                if let httpResponse = response as? HTTPURLResponse,
                   (200...299).contains(httpResponse.statusCode) {
                    self?.statusMessage = "LiDAR running!"
                    completion(.success(()))
                } else {
                    self?.errorMessage = "Server error"
                    self?.statusMessage = "LiDAR start failed"
                    completion(.failure(ScanError.serverError))
                }
            }
        }.resume()
    }

    /// Send command to Pi to stop LiDAR
    func stopRobotLidar(completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "\(serverBaseURL)/stop-lidar") else {
            completion(.failure(ScanError.invalidURL))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 10

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }

                if let httpResponse = response as? HTTPURLResponse,
                   (200...299).contains(httpResponse.statusCode) {
                    self?.statusMessage = "LiDAR stopped"
                    completion(.success(()))
                } else {
                    completion(.failure(ScanError.serverError))
                }
            }
        }.resume()
    }

    /// Check LiDAR status from Pi
    func checkLidarStatus(completion: @escaping (Result<LidarStatus, Error>) -> Void) {
        guard let url = URL(string: "\(serverBaseURL)/lidar-status") else {
            completion(.failure(ScanError.invalidURL))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }

                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let status = json["status"] as? String else {
                    completion(.failure(ScanError.serverError))
                    return
                }

                let lidarStatus = LidarStatus(
                    status: status,
                    pid: json["pid"] as? Int
                )
                completion(.success(lidarStatus))
            }
        }.resume()
    }

    // MARK: - Persistence

    /// Mark scan as completed for a user
    func markScanComplete(userId: String) {
        UserDefaults.standard.set(true, forKey: scanCompletedKeyPrefix + userId)
        UserDefaults.standard.set(Date(), forKey: lastScanDateKeyPrefix + userId)
    }

    /// Check if user has completed room scan
    func hasScanBeenCompleted(userId: String) -> Bool {
        return UserDefaults.standard.bool(forKey: scanCompletedKeyPrefix + userId)
    }

    /// Get last scan date for user
    func getLastScanDate(userId: String) -> Date? {
        return UserDefaults.standard.object(forKey: lastScanDateKeyPrefix + userId) as? Date
    }

    /// Reset for re-mapping
    func resetMapping() {
        isMapping = false
        mappingProgress = 0.0
        statusMessage = "Ready to map"
        errorMessage = nil
    }
}

// MARK: - Data Types

struct LidarStatus {
    let status: String      // "running", "stopped"
    let pid: Int?           // Process ID if running
}

// MARK: - Error Types

enum ScanError: LocalizedError {
    case noGridData
    case invalidURL
    case serverError
    case mappingFailed

    var errorDescription: String? {
        switch self {
        case .noGridData:
            return "No scan data available"
        case .invalidURL:
            return "Invalid server URL"
        case .serverError:
            return "Server returned an error"
        case .mappingFailed:
            return "LiDAR mapping failed"
        }
    }
}
