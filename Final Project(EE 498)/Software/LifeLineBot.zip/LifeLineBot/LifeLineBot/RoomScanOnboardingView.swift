//
//  RoomScanOnboardingView.swift
//  Created by Torryana Tanis
//  Function: First-time room mapping setup - triggers Pi's LiDAR to scan
//

import SwiftUI
import FirebaseAuth

/// Onboarding view for room mapping using the robot's LiDAR
struct RoomScanOnboardingView: View {

    @EnvironmentObject var authManager: AuthenticationManager
    @StateObject private var scanManager = RoomScanManager.shared

    // Mapping states
    enum MappingState {
        case idle
        case connecting
        case connected
        case loadingData
        case complete
    }

    @State private var mappingState: MappingState = .idle
    @State private var errorMessage: String?
    @State private var showError = false

    var onComplete: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    // Header icon
                    Image(systemName: "mappin.and.ellipse")
                        .font(.system(size: 70))
                        .foregroundStyle(.blue)
                        .padding(.top, 40)

                    // Title
                    Text("Room Setup Required")
                        .font(.title)
                        .fontWeight(.bold)

                    // Description
                    Text("LifeLineBot will use its LiDAR sensor to map your room so it can navigate to you during emergencies.")
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)

                    // Instructions
                    VStack(alignment: .leading, spacing: 16) {
                        Text("How it works:")
                            .font(.headline)

                        InstructionRow(number: 1, text: "Place the robot in the center of the room")
                        InstructionRow(number: 2, text: "Clear the path around the robot")
                        InstructionRow(number: 3, text: "Tap 'Start Mapping' below")
                        InstructionRow(number: 4, text: "The robot will scan 360° using LiDAR")
                        InstructionRow(number: 5, text: "Wait for mapping to complete")
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .padding(.horizontal)

                    // Tips
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Ensure robot has clear line of sight", systemImage: "eye")
                        Label("Remove temporary obstacles", systemImage: "shippingbox")
                        Label("Keep pets and people still", systemImage: "figure.stand")
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)

                    Spacer(minLength: 20)

                    // Mapping status based on state
                    switch mappingState {
                    case .idle:
                        // Start button
                        Button(action: { startMapping() }) {
                            HStack {
                                Image(systemName: "lidar.scanning")
                                Text("Start Mapping")
                            }
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundStyle(.white)
                            .cornerRadius(12)
                        }
                        .padding(.horizontal)

                        // Skip option
                        Button("Skip for now") {
                            onComplete()
                        }
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(.top, 8)

                    case .connecting:
                        ConnectingView()

                    case .connected:
                        ConnectedView()

                    case .loadingData:
                        LoadingDataView()

                    case .complete:
                        MappingCompleteView(onContinue: {
                            if let userId = authManager.currentUser?.uid {
                                scanManager.markScanComplete(userId: userId)
                            }
                            onComplete()
                        })
                    }

                    Spacer(minLength: 40)
                }
            }
            .navigationTitle("Room Setup")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Error", isPresented: $showError) {
                Button("OK") { }
            } message: {
                Text(errorMessage ?? "An error occurred")
            }
        }
    }

    private func startMapping() {
        mappingState = .connecting

        // Send mapping command to Pi
        scanManager.startRobotMapping { result in
            switch result {
            case .success:
                // Show "Connected" briefly
                mappingState = .connected

                // After 1.5 seconds, transition to loading data
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    mappingState = .loadingData

                    // Start polling for LiDAR completion
                    pollLidarStatus()
                }
            case .failure(let error):
                mappingState = .idle
                errorMessage = error.localizedDescription
                showError = true
            }
        }
    }

    private func pollLidarStatus() {
        // Poll every 2 seconds to check if LiDAR is done
        scanManager.checkLidarStatus { result in
            switch result {
            case .success(let status):
                if status.status == "stopped" || status.status == "complete" {
                    // LiDAR finished
                    mappingState = .complete
                } else {
                    // Still running, poll again
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        if mappingState == .loadingData {
                            pollLidarStatus()
                        }
                    }
                }
            case .failure:
                // On error, continue polling (connection might be temporarily lost)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    if mappingState == .loadingData {
                        pollLidarStatus()
                    }
                }
            }
        }
    }
}

// MARK: - Connecting View

struct ConnectingView: View {
    var body: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)

            Text("Connecting to Robot...")
                .font(.headline)

            Text("Establishing connection with LifeLineBot")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - Connected View

struct ConnectedView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 50))
                .foregroundStyle(.green)

            Text("Connected!")
                .font(.headline)
                .foregroundStyle(.green)

            Text("Successfully connected to the robot")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - Loading Data View

struct LoadingDataView: View {
    @State private var rotation = 0.0

    var body: some View {
        VStack(spacing: 16) {
            // Animated LiDAR icon
            Image(systemName: "lidar.scanning")
                .font(.system(size: 50))
                .foregroundStyle(.blue)
                .rotationEffect(.degrees(rotation))
                .onAppear {
                    withAnimation(.linear(duration: 2).repeatForever(autoreverses: false)) {
                        rotation = 360
                    }
                }

            Text("Scanning Room...")
                .font(.headline)

            Text("LiDAR data is loading. The robot is mapping your room.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            ProgressView()
                .scaleEffect(1.2)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - Mapping Complete View

struct MappingCompleteView: View {
    let onContinue: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 50))
                .foregroundStyle(.green)

            Text("Mapping Complete!")
                .font(.headline)

            Text("Your room has been mapped successfully. The robot can now navigate to you during emergencies.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button(action: onContinue) {
                Text("Continue to Dashboard")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
}

// MARK: - Instruction Row

struct InstructionRow: View {
    let number: Int
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Number circle
            Text("\(number)")
                .font(.caption)
                .fontWeight(.bold)
                .foregroundStyle(.white)
                .frame(width: 24, height: 24)
                .background(Color.blue)
                .clipShape(Circle())

            // Instruction text
            Text(text)
                .font(.subheadline)

            Spacer()
        }
    }
}

// MARK: - No LiDAR Warning

struct NoLiDARWarningView: View {
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.title2)
                    .foregroundStyle(.orange)

                Text("LiDAR Scanner Not Available")
                    .font(.headline)
            }

            Text("This feature requires an iPhone 12 Pro or later with LiDAR scanner. You can skip this step, but the robot will not be able to navigate automatically.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .background(Color.orange.opacity(0.1))
        .cornerRadius(12)
    }
}

#Preview {
    RoomScanOnboardingView(onComplete: {})
        .environmentObject(AuthenticationManager.shared)
}
