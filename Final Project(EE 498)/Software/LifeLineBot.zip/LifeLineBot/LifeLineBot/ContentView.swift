//  Content View
//
//  Created by Torryana Tanis
//  function: initalize comuuncation manager and loads to dashboard
import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct LifeLineBotApp: App {
    //manages authentication state
    @StateObject private var authManager = AuthenticationManager.shared
    //waits for incoming datd from watch
    @StateObject private var phoneSession = PhoneSessionManager.shared

    init() {
        FirebaseApp.configure()

        // Initialize BLE beacon manager (advertising starts when SOS is triggered)
        BLEBeaconManager.shared.initialize()
    }

    var body: some Scene {
        WindowGroup {
            if authManager.isLoggedIn {
                // Show dashboard
                DashboardView()
                    .environmentObject(phoneSession)
                    .environmentObject(authManager)
            } else {
                //shows auth screens when not logged in
                AuthContainerView()
                    .environmentObject(authManager)
            }
        }
    }
}
