//  AuthContainerView.swift
//
//  Created by Torryana Tanis
//  Function: Container view that switches between Login and SignUp screens

import SwiftUI

struct AuthContainerView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @State private var showSignUp: Bool = false

    var body: some View {
        Group {
            if showSignUp {
                SignUpView(showSignUp: $showSignUp)
                    .environmentObject(authManager)
            } else {
                LoginView(showSignUp: $showSignUp)
                    .environmentObject(authManager)
            }
        }
        .animation(.easeInOut, value: showSignUp)
    }
}

#Preview {
    AuthContainerView()
        .environmentObject(AuthenticationManager.shared)
}
