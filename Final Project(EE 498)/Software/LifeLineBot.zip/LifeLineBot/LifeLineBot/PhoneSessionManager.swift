//
//  PhoneSessionManager.swift
//  LifeLineBot
//
//  Created by Torryana Tanis on 11/17/25.
//  fucntion: manages all communciation ffrom watch
import Foundation
import WatchConnectivity
import Combine

// Pi server URL (Tailscale IP)
private let piServerURL = "http://100.95.21.127:5000"

// MARK: - Threshold Settings Model
struct ThresholdSettings: Codable {
    var highHRUpper: Int      // Tachycardia threshold (HIGH)
    var highHRLower: Int      // Bradycardia threshold (HIGH)
    var elevatedHRUpper: Int  // Elevated tachycardia
    var elevatedHRLower: Int  // Elevated bradycardia
    var highMotion: Double    // Fall detection threshold
    var elevatedMotion: Double // Unusual motion threshold

    static let `default` = ThresholdSettings(
        highHRUpper: 120,
        highHRLower: 45,
        elevatedHRUpper: 100,
        elevatedHRLower: 55,
        highMotion: 2.5,
        elevatedMotion: 2.0
    )

    func toDictionary() -> [String: Any] {
        return [
            "highHRUpper": highHRUpper,
            "highHRLower": highHRLower,
            "elevatedHRUpper": elevatedHRUpper,
            "elevatedHRLower": elevatedHRLower,
            "highMotion": highMotion,
            "elevatedMotion": elevatedMotion
        ]
    }

    static func from(dictionary: [String: Any]) -> ThresholdSettings? {
        guard let highHRUpper = dictionary["highHRUpper"] as? Int,
              let highHRLower = dictionary["highHRLower"] as? Int,
              let elevatedHRUpper = dictionary["elevatedHRUpper"] as? Int,
              let elevatedHRLower = dictionary["elevatedHRLower"] as? Int,
              let highMotion = dictionary["highMotion"] as? Double,
              let elevatedMotion = dictionary["elevatedMotion"] as? Double else {
            return nil
        }
        return ThresholdSettings(
            highHRUpper: highHRUpper,
            highHRLower: highHRLower,
            elevatedHRUpper: elevatedHRUpper,
            elevatedHRLower: elevatedHRLower,
            highMotion: highMotion,
            elevatedMotion: elevatedMotion
        )
    }
}

/// Receives sensor snapshots from the Apple Watch and sends them to the iphone's IU
final class PhoneSessionManager: NSObject, WCSessionDelegate, ObservableObject {

    static let shared = PhoneSessionManager()
    //waits for messages from watch
    private override init() {
        super.init()
        loadThresholdSettings()
        activateSession()
    }

    // MARK: - Threshold Settings Persistence

    private func saveThresholdSettings() {
        if let encoded = try? JSONEncoder().encode(thresholdSettings) {
            UserDefaults.standard.set(encoded, forKey: thresholdSettingsKey)
        }
    }

    private func loadThresholdSettings() {
        if let data = UserDefaults.standard.data(forKey: thresholdSettingsKey),
           let settings = try? JSONDecoder().decode(ThresholdSettings.self, from: data) {
            thresholdSettings = settings
        }
    }

    /// Sync current threshold settings to the watch
    func syncSettingsToWatch() {
        guard let session = session, session.isReachable else {
            print("iPhone: Watch not reachable for settings sync")
            return
        }

        let payload: [String: Any] = [
            "type": "thresholdSettings",
            "settings": thresholdSettings.toDictionary()
        ]

        session.sendMessage(payload, replyHandler: nil) { error in
            print("iPhone: Failed to sync settings: \(error.localizedDescription)")
        }

        print("iPhone: Synced threshold settings to watch")
    }
    //published properties that ui observes and updates
    @Published var lastHeartRate: Int = 0
    @Published var lastAccelX: Double = 0
    @Published var lastAccelY: Double = 0
    @Published var lastAccelZ: Double = 0
    @Published var lastUpdate: Date? = nil
    @Published var lastSOSRelayStatus: String = ""

    // Threshold settings (synced to watch)
    @Published var thresholdSettings: ThresholdSettings = .default {
        didSet {
            saveThresholdSettings()
            syncSettingsToWatch()
        }
    }

    private let thresholdSettingsKey = "thresholdSettings"

    //acess the default WCSession
    private var session: WCSession? {
        WCSession.isSupported() ? WCSession.default : nil
    }

    private func activateSession() {
        guard let session = session else { return }
        session.delegate = self
        session.activate()
    }

    // MARK: - WCSessionDelegate
    //alerts if connection with watch is ready
    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        if let error = error {
            print("iPhone WCSession activation error: \(error.localizedDescription)")
        } else {
            print("iPhone WCSession activation state: \(activationState.rawValue)")
        }
    }
    //required
    func sessionDidBecomeInactive(_ session: WCSession) { }
    func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }

    // Handle messages WITHOUT reply handler (fire-and-forget)
    func session(_ session: WCSession,
                 didReceiveMessage message: [String : Any]) {
        guard let type = message["type"] as? String else { return }

        if type == "sensorSnapshot" {
            handleSensorSnapshot(message)
        }
        // Note: sosRelay uses replyHandler, so it goes to the other method
    }

    // Handle messages WITH reply handler (SOS relay, BLE control)
    func session(_ session: WCSession,
                 didReceiveMessage message: [String : Any],
                 replyHandler: @escaping ([String : Any]) -> Void) {
        guard let type = message["type"] as? String else {
            replyHandler(["success": false, "message": "Unknown message type"])
            return
        }

        switch type {
        case "sosRelay":
            handleSOSRelay(replyHandler: replyHandler)
        case "sensorSnapshot":
            handleSensorSnapshot(message)
            replyHandler(["success": true])
        case "bleControl":
            handleBLEControl(message, replyHandler: replyHandler)
        default:
            replyHandler(["success": false, "message": "Unknown type: \(type)"])
        }
    }

    // MARK: - Message Handlers

    private func handleSensorSnapshot(_ message: [String: Any]) {
        let hr = message["heartRate"] as? Int ?? 0
        let ax = message["accelX"] as? Double ?? 0
        let ay = message["accelY"] as? Double ?? 0
        let az = message["accelZ"] as? Double ?? 0

        DispatchQueue.main.async {
            self.lastHeartRate = hr
            self.lastAccelX = ax
            self.lastAccelY = ay
            self.lastAccelZ = az
            self.lastUpdate = Date()
        }
    }

    /// Handle BLE control commands from watch (start/stop beacon advertising)
    private func handleBLEControl(_ message: [String: Any], replyHandler: @escaping ([String: Any]) -> Void) {
        guard let action = message["action"] as? String else {
            replyHandler(["success": false, "message": "Missing action"])
            return
        }

        print("iPhone: BLE control received - \(action)")

        DispatchQueue.main.async {
            switch action {
            case "start":
                BLEBeaconManager.shared.startSOSAdvertising()
                replyHandler(["success": true, "message": "BLE SOS advertising started"])
            case "stop":
                BLEBeaconManager.shared.stopSOSAdvertising()
                replyHandler(["success": true, "message": "BLE SOS advertising stopped"])
            default:
                replyHandler(["success": false, "message": "Unknown action: \(action)"])
            }
        }
    }

    /// Relay SOS from watch to Pi via Tailscale
    private func handleSOSRelay(replyHandler: @escaping ([String: Any]) -> Void) {
        print("iPhone: Relaying SOS to Pi...")

        guard let url = URL(string: "\(piServerURL)/sos") else {
            replyHandler(["success": false, "message": "Invalid URL"])
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 10

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    let msg = "Pi error: \(error.localizedDescription)"
                    self?.lastSOSRelayStatus = msg
                    print("iPhone: \(msg)")
                    replyHandler(["success": false, "message": msg])
                    return
                }

                if let httpResponse = response as? HTTPURLResponse,
                   (200...299).contains(httpResponse.statusCode) {
                    // Parse Pi response
                    var piMessage = "SOS sent, robot navigating to you"
                    if let data = data,
                       let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                       let msg = json["message"] as? String {
                        piMessage = msg
                    }

                    self?.lastSOSRelayStatus = "SOS relayed successfully"
                    print("iPhone: SOS relayed successfully - \(piMessage)")
                    replyHandler(["success": true, "message": piMessage])
                } else {
                    let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
                    let msg = "Pi returned status \(statusCode)"
                    self?.lastSOSRelayStatus = msg
                    print("iPhone: \(msg)")
                    replyHandler(["success": false, "message": msg])
                }
            }
        }.resume()
    }
}

