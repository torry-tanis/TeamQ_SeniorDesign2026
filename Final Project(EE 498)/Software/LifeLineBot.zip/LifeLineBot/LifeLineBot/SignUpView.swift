//  SignUpView.swift
//
//  Created by Torryana Tanis
//  Function: Registration screen for new users

import SwiftUI

struct SignUpView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @Binding var showSignUp: Bool

    // Account fields
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""

    // Profile fields
    @State private var fullName: String = ""
    @State private var phoneNumber: String = ""
    @State private var emergencyContactName: String = ""
    @State private var emergencyContactPhone: String = ""

    @State private var isLoading: Bool = false
    @State private var localError: String?

    private var passwordsMatch: Bool {
        password == confirmPassword
    }

    private var isFormValid: Bool {
        !email.isEmpty &&
        !password.isEmpty &&
        !confirmPassword.isEmpty &&
        passwordsMatch &&
        password.count >= 6 &&
        !fullName.isEmpty &&
        !phoneNumber.isEmpty &&
        !emergencyContactName.isEmpty &&
        !emergencyContactPhone.isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Logo and header
                VStack(spacing: 8) {
                    Image(systemName: "heart.circle.fill")
                        .font(.system(size: 70))
                        .foregroundStyle(.red)

                    Text("LifeLineBot")
                        .font(.largeTitle)
                        .fontWeight(.bold)

                    Text("Create your account")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.top, 30)

                // Profile Information Section
                VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Profile Information", icon: "person.fill")

                    CustomTextField(
                        icon: "person",
                        placeholder: "Full Name",
                        text: $fullName,
                        contentType: .name
                    )

                    CustomTextField(
                        icon: "phone",
                        placeholder: "Phone Number",
                        text: $phoneNumber,
                        keyboardType: .phonePad,
                        contentType: .telephoneNumber
                    )
                }
                .padding(.horizontal)

                // Emergency Contact Section
                VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Emergency Contact", icon: "exclamationmark.triangle.fill")

                    CustomTextField(
                        icon: "person.2",
                        placeholder: "Contact Name",
                        text: $emergencyContactName,
                        contentType: .name
                    )

                    CustomTextField(
                        icon: "phone.badge.plus",
                        placeholder: "Contact Phone",
                        text: $emergencyContactPhone,
                        keyboardType: .phonePad,
                        contentType: .telephoneNumber
                    )
                }
                .padding(.horizontal)

                // Account Section
                VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Account Details", icon: "lock.fill")

                    CustomTextField(
                        icon: "envelope",
                        placeholder: "Email",
                        text: $email,
                        keyboardType: .emailAddress,
                        contentType: .emailAddress,
                        autocapitalization: false
                    )

                    CustomSecureField(
                        icon: "lock",
                        placeholder: "Password",
                        text: $password
                    )

                    CustomSecureField(
                        icon: "lock.rotation",
                        placeholder: "Confirm Password",
                        text: $confirmPassword
                    )

                    // Password requirements hint
                    if !password.isEmpty && password.count < 6 {
                        HintLabel(text: "Password must be at least 6 characters", color: .orange)
                    }

                    // Password match indicator
                    if !confirmPassword.isEmpty && !passwordsMatch {
                        HintLabel(text: "Passwords do not match", color: .red)
                    }
                }
                .padding(.horizontal)

                // Error message
                if let errorMessage = localError ?? authManager.errorMessage {
                    Text(errorMessage)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }

                // Create account button
                Button {
                    signUp()
                } label: {
                    HStack {
                        if isLoading {
                            ProgressView()
                                .tint(.white)
                        } else {
                            Image(systemName: "person.badge.plus")
                            Text("Create Account")
                                .fontWeight(.semibold)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(isFormValid ? Color.blue : Color.gray.opacity(0.5))
                    .foregroundStyle(.white)
                    .cornerRadius(12)
                }
                .disabled(!isFormValid || isLoading)
                .padding(.horizontal)
                .padding(.top, 8)

                // Back to login link
                HStack {
                    Text("Already have an account?")
                        .foregroundStyle(.secondary)
                    Button("Sign In") {
                        showSignUp = false
                    }
                    .fontWeight(.semibold)
                }
                .font(.subheadline)
                .padding(.vertical, 20)
            }
        }
        .background(Color(.systemGroupedBackground))
    }

    private func signUp() {
        localError = nil

        guard passwordsMatch else {
            localError = "Passwords do not match"
            return
        }

        guard password.count >= 6 else {
            localError = "Password must be at least 6 characters"
            return
        }

        isLoading = true
        Task {
            do {
                let profile = UserProfile(
                    fullName: fullName,
                    phoneNumber: phoneNumber,
                    emergencyContactName: emergencyContactName,
                    emergencyContactPhone: emergencyContactPhone
                )
                try await authManager.signUp(email: email, password: password, profile: profile)
            } catch {
                // Error is handled by authManager
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

// MARK: - Supporting Views

struct SectionHeader: View {
    let title: String
    let icon: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundStyle(.blue)
            Text(title)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundStyle(.secondary)
        }
        .padding(.leading, 4)
    }
}

struct CustomTextField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var contentType: UITextContentType? = nil
    var autocapitalization: Bool = true

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(.gray)
                .frame(width: 20)

            TextField(placeholder, text: $text)
                .keyboardType(keyboardType)
                .textContentType(contentType)
                .autocapitalization(autocapitalization ? .words : .none)
                .autocorrectionDisabled()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color(.systemGray4), lineWidth: 1)
        )
    }
}

struct CustomSecureField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    @State private var isVisible: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(.gray)
                .frame(width: 20)

            if isVisible {
                TextField(placeholder, text: $text)
                    .textContentType(.password)
                    .autocapitalization(.none)
                    .autocorrectionDisabled()
            } else {
                SecureField(placeholder, text: $text)
                    .textContentType(.password)
            }

            Button {
                isVisible.toggle()
            } label: {
                Image(systemName: isVisible ? "eye.slash" : "eye")
                    .foregroundStyle(.gray)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color(.systemGray4), lineWidth: 1)
        )
    }
}

struct HintLabel: View {
    let text: String
    let color: Color

    var body: some View {
        HStack {
            Image(systemName: "exclamationmark.circle")
            Text(text)
        }
        .font(.caption)
        .foregroundStyle(color)
        .padding(.leading, 4)
    }
}

#Preview {
    SignUpView(showSignUp: .constant(true))
        .environmentObject(AuthenticationManager.shared)
}
