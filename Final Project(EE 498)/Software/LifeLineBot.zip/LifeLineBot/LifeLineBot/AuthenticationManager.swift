//  AuthenticationManager.swift
//
//  Created by Torryana Tanis
//  Function: Manages Firebase authentication state

import SwiftUI
import Combine
import FirebaseAuth

// MARK: - User Profile Model
struct UserProfile: Codable {
    let fullName: String
    let phoneNumber: String
    let emergencyContactName: String
    let emergencyContactPhone: String
    var email: String?
    var createdAt: Date?

    init(fullName: String, phoneNumber: String, emergencyContactName: String, emergencyContactPhone: String) {
        self.fullName = fullName
        self.phoneNumber = phoneNumber
        self.emergencyContactName = emergencyContactName
        self.emergencyContactPhone = emergencyContactPhone
    }
}

final class AuthenticationManager: ObservableObject {
    static let shared = AuthenticationManager()

    @Published var isLoggedIn: Bool = false
    @Published var currentUser: User?
    @Published var userProfile: UserProfile?
    @Published var errorMessage: String?

    private let profileKey = "userProfile"

    private init() {
        // Listen for auth state changes
        _ = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async {
                self?.currentUser = user
                self?.isLoggedIn = user != nil

                // Load user profile when logged in
                if let userId = user?.uid {
                    self?.loadUserProfile(userId: userId)
                } else {
                    self?.userProfile = nil
                }
            }
        }
    }

    /// Creates a new user account with email, password, and profile data
    func signUp(email: String, password: String, profile: UserProfile) async throws {
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)

            // Save profile locally
            var profileData = profile
            profileData.email = email
            profileData.createdAt = Date()

            saveUserProfile(userId: result.user.uid, profile: profileData)

            await MainActor.run {
                self.currentUser = result.user
                self.userProfile = profileData
                self.isLoggedIn = true
                self.errorMessage = nil
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
            }
            throw error
        }
    }

    /// Signs in an existing user with email and password
    func signIn(email: String, password: String) async throws {
        do {
            let result = try await Auth.auth().signIn(withEmail: email, password: password)
            await MainActor.run {
                self.currentUser = result.user
                self.isLoggedIn = true
                self.errorMessage = nil
            }
            // Profile will be loaded by the auth state listener
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
            }
            throw error
        }
    }

    /// Signs out the current user
    func signOut() {
        do {
            try Auth.auth().signOut()
            self.currentUser = nil
            self.userProfile = nil
            self.isLoggedIn = false
            self.errorMessage = nil
        } catch {
            self.errorMessage = error.localizedDescription
        }
    }

    // MARK: - Local Storage Operations

    /// Saves user profile to UserDefaults
    func saveUserProfile(userId: String, profile: UserProfile) {
        if let encoded = try? JSONEncoder().encode(profile) {
            UserDefaults.standard.set(encoded, forKey: "\(profileKey)_\(userId)")
        }
    }

    /// Loads user profile from UserDefaults
    private func loadUserProfile(userId: String) {
        if let data = UserDefaults.standard.data(forKey: "\(profileKey)_\(userId)"),
           let profile = try? JSONDecoder().decode(UserProfile.self, from: data) {
            DispatchQueue.main.async {
                self.userProfile = profile
            }
        }
    }

    /// Updates emergency contact information
    func updateEmergencyContact(name: String, phone: String) {
        guard let userId = currentUser?.uid,
              let currentProfile = userProfile else { return }

        let updatedProfile = UserProfile(
            fullName: currentProfile.fullName,
            phoneNumber: currentProfile.phoneNumber,
            emergencyContactName: name,
            emergencyContactPhone: phone
        )

        var profileData = updatedProfile
        profileData.email = currentProfile.email
        profileData.createdAt = currentProfile.createdAt

        saveUserProfile(userId: userId, profile: profileData)

        DispatchQueue.main.async {
            self.userProfile = profileData
        }
    }
}
