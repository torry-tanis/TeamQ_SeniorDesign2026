//  LifeLineBotApp
//
//  Created by Torryana Tanis
//  Function: displays live data from watch
import SwiftUI
import FirebaseAuth
import Combine

// MARK: - iPhone SOS Manager
/// Handles SOS functionality directly from the iPhone
class iPhoneSOSManager: ObservableObject {
    static let shared = iPhoneSOSManager()

    // Pi server URL (Tailscale IP)
    private let piServerURL = "http://100.95.21.127:5000"

    @Published var isSending = false
    @Published var statusMessage = ""
    @Published var lastResult: SOSResult = .idle
    @Published var sosReceived = false

    enum SOSResult {
        case idle
        case success
        case failure
    }

    var buttonColor: Color {
        switch lastResult {
        case .idle: return .red
        case .success: return .green
        case .failure: return .orange
        }
    }

    var statusColor: Color {
        switch lastResult {
        case .idle: return .gray
        case .success: return .green
        case .failure: return .red
        }
    }

    private init() {}

    func sendSOS() {
        guard !isSending else { return }

        isSending = true
        statusMessage = "Sending SOS..."
        lastResult = .idle

        // Start BLE advertising so robot can detect and range the iPhone
        BLEBeaconManager.shared.startSOSAdvertising()

        guard let url = URL(string: "\(piServerURL)/sos") else {
            statusMessage = "Invalid URL"
            lastResult = .failure
            isSending = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 10

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isSending = false

                if let error = error {
                    self?.statusMessage = "Failed: \(error.localizedDescription)"
                    self?.lastResult = .failure
                    return
                }

                if let httpResponse = response as? HTTPURLResponse,
                   (200...299).contains(httpResponse.statusCode) {
                    self?.statusMessage = "SOS Sent! Help is on the way."
                    self?.lastResult = .success
                    self?.sosReceived = true
                } else {
                    self?.statusMessage = "Server Error"
                    self?.lastResult = .failure
                }
            }
        }.resume()
    }

    func reset() {
        sosReceived = false
        statusMessage = ""
        lastResult = .idle

        // Stop BLE advertising when SOS is cancelled/dismissed
        BLEBeaconManager.shared.stopSOSAdvertising()
    }
}

struct DashboardView: View {
    //pulls in shared seesion manger that recieves daa from watch
    @EnvironmentObject var session: PhoneSessionManager
    @EnvironmentObject var authManager: AuthenticationManager
    @StateObject private var sosManager = iPhoneSOSManager.shared

    // State for editing emergency contact
    @State private var showEditEmergencyContact = false

    // State for threshold settings
    @State private var showThresholdSettings = false

    //computes accel. magnitude
    private var accelMagnitude: Double {
        let x = session.lastAccelX
        let y = session.lastAccelY
        let z = session.lastAccelZ
        return sqrt(x * x + y * y + z * z)
    }
    //displays status message
    private var statusText: String {
        guard session.lastUpdate != nil else {
            return "Waiting for data from LifeLineBot Watch..."
        }
        return "Receiving live data from LifeLineBot Watch."
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                // Welcome header with user name
                if let profile = authManager.userProfile {
                    Text("Welcome, \(profile.fullName.components(separatedBy: " ").first ?? "User")")
                        .font(.title2)
                        .fontWeight(.semibold)
                } else {
                    Text("LifeLineBot iPhone")
                        .font(.title2)
                        .fontWeight(.semibold)
                }

                //shows whether the watch is sending data
                Text(statusText)
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)

                Divider()

                //display the latest vitals and motion data recieved
                VStack(alignment: .leading, spacing: 8) {
                    Text("Latest Heart Rate: \(session.lastHeartRate) bpm")
                        .font(.headline)
                    Text(String(format: "Accel |a|: %.2f g", accelMagnitude))
                        .font(.subheadline)
                    //raw accel. readings
                    Text(String(format: "X: %.2f   Y: %.2f   Z: %.2f",
                                session.lastAccelX,
                                session.lastAccelY,
                                session.lastAccelZ))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                // Emergency contact info
                if let profile = authManager.userProfile {
                    Divider()

                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("Emergency Contact")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                            Button("Edit") {
                                showEditEmergencyContact = true
                            }
                            .font(.caption)
                        }
                        HStack {
                            Image(systemName: "person.2.fill")
                                .foregroundStyle(.red)
                            Text("\(profile.emergencyContactName)")
                                .font(.subheadline)
                        }
                        HStack {
                            Image(systemName: "phone.fill")
                                .foregroundStyle(.green)
                            Text("\(profile.emergencyContactPhone)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }

                Spacer()

                // MARK: - SOS Button Section
                if sosManager.sosReceived {
                    // SOS Received confirmation
                    VStack(spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 50))
                            .foregroundStyle(.green)

                        Text("SOS RECEIVED")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundStyle(.green)

                        Text("Help is on the way")
                            .font(.subheadline)
                            .foregroundStyle(.gray)

                        Button("Dismiss") {
                            sosManager.reset()
                        }
                        .buttonStyle(.bordered)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                } else {
                    // SOS Button
                    VStack(spacing: 8) {
                        Button(action: {
                            sosManager.sendSOS()
                        }) {
                            HStack {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .font(.title2)
                                Text("SOS Emergency")
                                    .font(.title3)
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(sosManager.buttonColor)
                        .disabled(sosManager.isSending)

                        // Status message
                        if !sosManager.statusMessage.isEmpty {
                            Text(sosManager.statusMessage)
                                .font(.caption)
                                .foregroundStyle(sosManager.statusColor)
                        }

                        Text("Tap to alert emergency contacts and send robot to your location")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
            }
            .padding()
            .navigationTitle("Current Vitals")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showThresholdSettings = true
                    } label: {
                        Image(systemName: "gearshape")
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Sign Out") {
                        authManager.signOut()
                    }
                    .foregroundStyle(.red)
                }
            }
            .sheet(isPresented: $showEditEmergencyContact) {
                EditEmergencyContactView()
                    .environmentObject(authManager)
            }
            .sheet(isPresented: $showThresholdSettings) {
                ThresholdSettingsView()
                    .environmentObject(session)
            }
        }
    }

}

// MARK: - Edit Emergency Contact View
struct EditEmergencyContactView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @Environment(\.dismiss) var dismiss

    @State private var contactName: String = ""
    @State private var contactPhone: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Emergency Contact Details")) {
                    TextField("Contact Name", text: $contactName)
                        .textContentType(.name)
                        .autocapitalization(.words)

                    TextField("Phone Number", text: $contactPhone)
                        .textContentType(.telephoneNumber)
                        .keyboardType(.phonePad)
                }

                Section {
                    Text("This contact will be notified when you trigger an SOS alert.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Edit Contact")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        authManager.updateEmergencyContact(name: contactName, phone: contactPhone)
                        dismiss()
                    }
                    .disabled(contactName.isEmpty || contactPhone.isEmpty)
                }
            }
            .onAppear {
                // Pre-fill with current values
                if let profile = authManager.userProfile {
                    contactName = profile.emergencyContactName
                    contactPhone = profile.emergencyContactPhone
                }
            }
        }
    }
}

// MARK: - Threshold Settings View
struct ThresholdSettingsView: View {
    @EnvironmentObject var session: PhoneSessionManager
    @Environment(\.dismiss) var dismiss

    @State private var highHRUpper: Double = 120
    @State private var highHRLower: Double = 45
    @State private var elevatedHRUpper: Double = 100
    @State private var elevatedHRLower: Double = 55
    @State private var highMotion: Double = 2.5
    @State private var elevatedMotion: Double = 2.0

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("High Risk - Heart Rate")) {
                    VStack(alignment: .leading) {
                        Text("Tachycardia (High HR): > \(Int(highHRUpper)) BPM")
                            .font(.subheadline)
                        Slider(value: $highHRUpper, in: 100...160, step: 5)
                    }
                    VStack(alignment: .leading) {
                        Text("Bradycardia (Low HR): < \(Int(highHRLower)) BPM")
                            .font(.subheadline)
                        Slider(value: $highHRLower, in: 30...55, step: 5)
                    }
                }

                Section(header: Text("Elevated Risk - Heart Rate")) {
                    VStack(alignment: .leading) {
                        Text("Mild Tachycardia: > \(Int(elevatedHRUpper)) BPM")
                            .font(.subheadline)
                        Slider(value: $elevatedHRUpper, in: 85...120, step: 5)
                    }
                    VStack(alignment: .leading) {
                        Text("Mild Bradycardia: < \(Int(elevatedHRLower)) BPM")
                            .font(.subheadline)
                        Slider(value: $elevatedHRLower, in: 45...65, step: 5)
                    }
                }

                Section(header: Text("Motion / Fall Detection")) {
                    VStack(alignment: .leading) {
                        Text("High Risk (Fall): > \(String(format: "%.1f", highMotion))g")
                            .font(.subheadline)
                        Slider(value: $highMotion, in: 2.0...4.0, step: 0.1)
                    }
                    VStack(alignment: .leading) {
                        Text("Elevated Risk: > \(String(format: "%.1f", elevatedMotion))g")
                            .font(.subheadline)
                        Slider(value: $elevatedMotion, in: 1.5...3.0, step: 0.1)
                    }
                }

                Section {
                    Button("Reset to Defaults") {
                        resetToDefaults()
                    }
                    .foregroundStyle(.orange)
                }

                Section {
                    Text("These thresholds determine when the watch displays HIGH, ELEVATED, or NORMAL risk levels. Adjust based on the patient's baseline vitals and medications.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Risk Thresholds")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .onAppear {
                loadCurrentSettings()
            }
        }
    }

    private func loadCurrentSettings() {
        let settings = session.thresholdSettings
        highHRUpper = Double(settings.highHRUpper)
        highHRLower = Double(settings.highHRLower)
        elevatedHRUpper = Double(settings.elevatedHRUpper)
        elevatedHRLower = Double(settings.elevatedHRLower)
        highMotion = settings.highMotion
        elevatedMotion = settings.elevatedMotion
    }

    private func saveSettings() {
        session.thresholdSettings = ThresholdSettings(
            highHRUpper: Int(highHRUpper),
            highHRLower: Int(highHRLower),
            elevatedHRUpper: Int(elevatedHRUpper),
            elevatedHRLower: Int(elevatedHRLower),
            highMotion: highMotion,
            elevatedMotion: elevatedMotion
        )
        // Settings are automatically synced to watch via didSet
    }

    private func resetToDefaults() {
        let defaults = ThresholdSettings.default
        highHRUpper = Double(defaults.highHRUpper)
        highHRLower = Double(defaults.highHRLower)
        elevatedHRUpper = Double(defaults.elevatedHRUpper)
        elevatedHRLower = Double(defaults.elevatedHRLower)
        highMotion = defaults.highMotion
        elevatedMotion = defaults.elevatedMotion
    }
}

#Preview {
    //preview with phone session manger so UI can work properly
    DashboardView()
        .environmentObject(PhoneSessionManager.shared)
        .environmentObject(AuthenticationManager.shared)
}
