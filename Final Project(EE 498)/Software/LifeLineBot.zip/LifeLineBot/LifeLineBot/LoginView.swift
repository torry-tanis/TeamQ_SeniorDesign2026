//  LoginView.swift
//
//  Created by Torryana Tanis
//  Function: Login screen for existing users

import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @Binding var showSignUp: Bool

    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isLoading: Bool = false

    private var isFormValid: Bool {
        !email.isEmpty && !password.isEmpty
    }

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            // Logo and app title
            VStack(spacing: 12) {
                Image(systemName: "heart.circle.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(.red)

                Text("LifeLineBot")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text("Sign in to continue")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
                .frame(height: 50)

            // Input fields
            VStack(spacing: 16) {
                CustomTextField(
                    icon: "envelope",
                    placeholder: "Email",
                    text: $email,
                    keyboardType: .emailAddress,
                    contentType: .emailAddress,
                    autocapitalization: false
                )

                CustomSecureField(
                    icon: "lock",
                    placeholder: "Password",
                    text: $password
                )
            }
            .padding(.horizontal, 24)

            // Error message
            if let errorMessage = authManager.errorMessage {
                HStack {
                    Image(systemName: "exclamationmark.circle")
                    Text(errorMessage)
                }
                .font(.caption)
                .foregroundStyle(.red)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
                .padding(.top, 12)
            }

            // Sign in button
            Button {
                signIn()
            } label: {
                HStack {
                    if isLoading {
                        ProgressView()
                            .tint(.white)
                    } else {
                        Image(systemName: "arrow.right.circle.fill")
                        Text("Sign In")
                            .fontWeight(.semibold)
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(isFormValid ? Color.blue : Color.gray.opacity(0.5))
                .foregroundStyle(.white)
                .cornerRadius(12)
            }
            .disabled(!isFormValid || isLoading)
            .padding(.horizontal, 24)
            .padding(.top, 24)

            Spacer()

            // Sign up link
            VStack(spacing: 16) {
                Divider()
                    .padding(.horizontal, 40)

                HStack {
                    Text("Don't have an account?")
                        .foregroundStyle(.secondary)
                    Button("Sign Up") {
                        showSignUp = true
                    }
                    .fontWeight(.semibold)
                }
                .font(.subheadline)
            }
            .padding(.bottom, 30)
        }
        .background(Color(.systemGroupedBackground))
    }

    private func signIn() {
        isLoading = true
        Task {
            do {
                try await authManager.signIn(email: email, password: password)
            } catch {
                // Error is handled by authManager
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

#Preview {
    LoginView(showSignUp: .constant(false))
        .environmentObject(AuthenticationManager.shared)
}
