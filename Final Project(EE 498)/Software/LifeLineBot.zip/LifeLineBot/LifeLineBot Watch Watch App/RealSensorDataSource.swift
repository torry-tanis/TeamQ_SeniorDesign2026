//
//  RealSensorDataSource.swift
//  Created by Torryana Tanis
//  Function: Collects real sensor data from Apple Watch using HealthKit and CoreMotion

import Foundation
import HealthKit
import CoreMotion
import Combine

final class RealSensorDataSource: ObservableObject {

    // Published sensor values
    @Published var heartRateBPM: Int = 0
    @Published var accelX: Double = 0.0
    @Published var accelY: Double = 0.0
    @Published var accelZ: Double = -1.0
    @Published var isAuthorized: Bool = false
    @Published var errorMessage: String?

    // HealthKit
    private let healthStore = HKHealthStore()
    private var heartRateQuery: HKAnchoredObjectQuery?

    // CoreMotion
    private let motionManager = CMMotionManager()
    private let motionQueue = OperationQueue()

    // Timer for sending data to iPhone
    private var sendTimer: Timer?

    init() {
        motionQueue.name = "MotionQueue"
        motionQueue.maxConcurrentOperationCount = 1
    }

    // MARK: - Public Methods

    /// Request permissions and start collecting data
    func start() {
        requestHealthKitAuthorization()
        startAccelerometer()
        startSendingData()
    }

    /// Stop all data collection
    func stop() {
        stopHeartRateQuery()
        stopAccelerometer()
        stopSendingData()
    }

    // MARK: - HealthKit Authorization

    private func requestHealthKitAuthorization() {
        // Check if HealthKit is available
        guard HKHealthStore.isHealthDataAvailable() else {
            DispatchQueue.main.async {
                self.errorMessage = "HealthKit not available"
            }
            return
        }

        // Define the heart rate type we want to read
        guard let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate) else {
            return
        }

        let typesToRead: Set<HKSampleType> = [heartRateType]

        // Request authorization
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { [weak self] success, error in
            DispatchQueue.main.async {
                if success {
                    self?.isAuthorized = true
                    self?.startHeartRateQuery()
                } else {
                    self?.errorMessage = error?.localizedDescription ?? "Authorization failed"
                }
            }
        }
    }

    // MARK: - Heart Rate Monitoring

    private func startHeartRateQuery() {
        guard let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate) else {
            return
        }

        // Create a predicate to get recent heart rate samples
        let predicate = HKQuery.predicateForSamples(
            withStart: Date().addingTimeInterval(-60), // Last minute
            end: nil,
            options: .strictStartDate
        )

        // Create an anchored object query for real-time updates
        let query = HKAnchoredObjectQuery(
            type: heartRateType,
            predicate: predicate,
            anchor: nil,
            limit: HKObjectQueryNoLimit
        ) { [weak self] _, samples, _, _, error in
            self?.processHeartRateSamples(samples)
        }

        // Set up the update handler for continuous monitoring
        query.updateHandler = { [weak self] _, samples, _, _, error in
            self?.processHeartRateSamples(samples)
        }

        heartRateQuery = query
        healthStore.execute(query)
    }

    private func processHeartRateSamples(_ samples: [HKSample]?) {
        guard let heartRateSamples = samples as? [HKQuantitySample],
              let mostRecent = heartRateSamples.last else {
            return
        }

        // Convert to BPM
        let heartRateUnit = HKUnit.count().unitDivided(by: .minute())
        let heartRate = Int(mostRecent.quantity.doubleValue(for: heartRateUnit))

        DispatchQueue.main.async {
            self.heartRateBPM = heartRate
        }
    }

    private func stopHeartRateQuery() {
        if let query = heartRateQuery {
            healthStore.stop(query)
            heartRateQuery = nil
        }
    }

    // MARK: - Accelerometer

    private func startAccelerometer() {
        guard motionManager.isAccelerometerAvailable else {
            DispatchQueue.main.async {
                self.errorMessage = "Accelerometer not available"
            }
            return
        }

        // Update at 10 Hz
        motionManager.accelerometerUpdateInterval = 0.1

        motionManager.startAccelerometerUpdates(to: motionQueue) { [weak self] data, error in
            guard let data = data, error == nil else {
                return
            }

            DispatchQueue.main.async {
                self?.accelX = data.acceleration.x
                self?.accelY = data.acceleration.y
                self?.accelZ = data.acceleration.z
            }
        }
    }

    private func stopAccelerometer() {
        motionManager.stopAccelerometerUpdates()
    }

    // MARK: - Send Data to iPhone

    private func startSendingData() {
        // Send data to iPhone every 0.5 seconds
        sendTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }

            WatchConnectivityManager.shared.sendSensorSnapshot(
                heartRate: self.heartRateBPM,
                accelX: self.accelX,
                accelY: self.accelY,
                accelZ: self.accelZ
            )
        }
    }

    private func stopSendingData() {
        sendTimer?.invalidate()
        sendTimer = nil
    }

    deinit {
        stop()
    }
}
