//
//  WatchConnectivityManager.swift
//  Created by Torryana Tanis
// fucntion: hamgles communcaiton from watch to phone

import Foundation
import WatchConnectivity
import Combine

// MARK: - Threshold Settings (synced from iPhone)
struct WatchThresholdSettings {
    var highHRUpper: Int = 120
    var highHRLower: Int = 45
    var elevatedHRUpper: Int = 100
    var elevatedHRLower: Int = 55
    var highMotion: Double = 2.5
    var elevatedMotion: Double = 2.0

    static func from(dictionary: [String: Any]) -> WatchThresholdSettings {
        var settings = WatchThresholdSettings()
        if let val = dictionary["highHRUpper"] as? Int { settings.highHRUpper = val }
        if let val = dictionary["highHRLower"] as? Int { settings.highHRLower = val }
        if let val = dictionary["elevatedHRUpper"] as? Int { settings.elevatedHRUpper = val }
        if let val = dictionary["elevatedHRLower"] as? Int { settings.elevatedHRLower = val }
        if let val = dictionary["highMotion"] as? Double { settings.highMotion = val }
        if let val = dictionary["elevatedMotion"] as? Double { settings.elevatedMotion = val }
        return settings
    }
}

/// Handles sending messages from the Watch to the paired iPhone.
final class WatchConnectivityManager: NSObject, WCSessionDelegate, ObservableObject {

    static let shared = WatchConnectivityManager()

    // Threshold settings received from iPhone
    @Published var thresholdSettings = WatchThresholdSettings()

    private let settingsKey = "watchThresholdSettings"

    private override init() {
        super.init()
        loadSettings()
        activateSession()
    }

    private var session: WCSession? {
        WCSession.isSupported() ? WCSession.default : nil
    }

    /// Check if iPhone is reachable for relay
    var isPhoneReachable: Bool {
        session?.isReachable ?? false
    }

    // MARK: - Settings Persistence

    private func loadSettings() {
        if let data = UserDefaults.standard.dictionary(forKey: settingsKey) {
            thresholdSettings = WatchThresholdSettings.from(dictionary: data)
            print("Watch: Loaded saved threshold settings")
        }
    }

    private func saveSettings(_ settings: WatchThresholdSettings) {
        let dict: [String: Any] = [
            "highHRUpper": settings.highHRUpper,
            "highHRLower": settings.highHRLower,
            "elevatedHRUpper": settings.elevatedHRUpper,
            "elevatedHRLower": settings.elevatedHRLower,
            "highMotion": settings.highMotion,
            "elevatedMotion": settings.elevatedMotion
        ]
        UserDefaults.standard.set(dict, forKey: settingsKey)
    }

    private func activateSession() {
        guard let session = session else { return }
        session.delegate = self
        session.activate()
    }

    /// Send a single snapshot of the current sensor state to the iPhone.
    func sendSensorSnapshot(heartRate: Int,
                            accelX: Double,
                            accelY: Double,
                            accelZ: Double) {
        guard let session = session, session.isReachable else {
            return
        }

        let payload: [String: Any] = [
            "type": "sensorSnapshot",
            "heartRate": heartRate,
            "accelX": accelX,
            "accelY": accelY,
            "accelZ": accelZ,
            "timestamp": Date().timeIntervalSince1970
        ]

        session.sendMessage(payload, replyHandler: nil) { error in
            print("Watch send error: \(error.localizedDescription)")
        }
    }

    /// Send SOS request to iPhone for relay to Pi via Tailscale
    /// - Parameter completion: Called with (success, message) when iPhone responds
    func sendSOSViaPhone(completion: @escaping (Bool, String) -> Void) {
        guard let session = session else {
            completion(false, "WCSession not supported")
            return
        }

        guard session.isReachable else {
            completion(false, "iPhone not reachable")
            return
        }

        let payload: [String: Any] = [
            "type": "sosRelay",
            "timestamp": Date().timeIntervalSince1970
        ]

        session.sendMessage(payload, replyHandler: { reply in
            // iPhone responded with result from Pi
            let success = reply["success"] as? Bool ?? false
            let message = reply["message"] as? String ?? "Unknown response"
            DispatchQueue.main.async {
                completion(success, message)
            }
        }, errorHandler: { error in
            DispatchQueue.main.async {
                completion(false, "Relay failed: \(error.localizedDescription)")
            }
        })
    }

    // MARK: - BLE Control (triggers iPhone to advertise BLE beacon)

    /// Tell iPhone to start BLE beacon advertising
    func startBLEBeaconOnPhone() {
        guard let session = session, session.isReachable else {
            print("Watch: iPhone not reachable for BLE start")
            return
        }

        let payload: [String: Any] = [
            "type": "bleControl",
            "action": "start"
        ]

        session.sendMessage(payload, replyHandler: { reply in
            let success = reply["success"] as? Bool ?? false
            print("Watch: iPhone BLE start \(success ? "succeeded" : "failed")")
        }, errorHandler: { error in
            print("Watch: Failed to send BLE start: \(error.localizedDescription)")
        })
    }

    /// Tell iPhone to stop BLE beacon advertising
    func stopBLEBeaconOnPhone() {
        guard let session = session, session.isReachable else {
            print("Watch: iPhone not reachable for BLE stop")
            return
        }

        let payload: [String: Any] = [
            "type": "bleControl",
            "action": "stop"
        ]

        session.sendMessage(payload, replyHandler: nil) { error in
            print("Watch: Failed to send BLE stop: \(error.localizedDescription)")
        }
    }

    // MARK: - WCSessionDelegate stubs
    //WCSession is the communciation channel
    //function: notifies if watch sucessfully connected to iphone
    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        if let error = error {
            print("WCSession activation failed: \(error.localizedDescription)")
        } else {
            print("WCSession activated with state: \(activationState.rawValue)")
            // Auto-start BLE on iPhone when watch connects
            if activationState == .activated {
                startBLEBeaconOnPhone()
            }
        }
    }

    //function: reachability monioting (required by ios)
    func sessionReachabilityDidChange(_ session: WCSession) {
        // When iPhone becomes reachable, start BLE beacon
        if session.isReachable {
            startBLEBeaconOnPhone()
        }
    }

    // MARK: - Receive Messages from iPhone

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        guard let type = message["type"] as? String else { return }

        if type == "thresholdSettings" {
            if let settingsDict = message["settings"] as? [String: Any] {
                let newSettings = WatchThresholdSettings.from(dictionary: settingsDict)
                DispatchQueue.main.async {
                    self.thresholdSettings = newSettings
                    self.saveSettings(newSettings)
                    print("Watch: Received and saved threshold settings from iPhone")
                }
            }
        }
    }
}
