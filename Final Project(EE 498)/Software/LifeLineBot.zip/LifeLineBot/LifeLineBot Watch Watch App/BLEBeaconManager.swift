//
//  BLEBeaconManager.swift
//  LifeLineBot Watch Watch App
//
//  Created by Torryana Tanis
//  Function: Broadcasts simple BLE beacon so robot can track watch location

import Foundation
import CoreBluetooth
import Combine

/// Manages BLE advertising to broadcast the watch's location to the robot.
/// Uses simplified advertising compatible with watchOS limitations.
final class BLEBeaconManager: NSObject, ObservableObject {

    static let shared = BLEBeaconManager()

    // Unique service UUID for LifeLineBot Watch
    static let serviceUUID = CBUUID(string: "12345678-1234-1234-1234-123456789ABC")

    private var peripheralManager: CBPeripheralManager?

    @Published var isAdvertising = false
    @Published var bluetoothState: String = "Unknown"

    private override init() {
        super.init()
    }

    /// Start the BLE peripheral manager
    func start() {
        guard peripheralManager == nil else {
            print("BLE Watch: Already initialized")
            return
        }

        print("BLE Watch: Initializing...")
        // Use default initialization without queue parameter for watchOS compatibility
        peripheralManager = CBPeripheralManager()
        peripheralManager?.delegate = self
    }

    /// Stop advertising
    func stop() {
        peripheralManager?.stopAdvertising()
        isAdvertising = false
        print("BLE Watch: Stopped")
    }

    /// Start advertising - called when Bluetooth is ready
    private func startAdvertising() {
        guard let manager = peripheralManager else { return }

        guard manager.state == .poweredOn else {
            print("BLE Watch: Bluetooth not ready")
            return
        }

        // Simple advertisement with just service UUID - no characteristics needed
        let advertisementData: [String: Any] = [
            CBAdvertisementDataServiceUUIDsKey: [BLEBeaconManager.serviceUUID],
            CBAdvertisementDataLocalNameKey: "LLWatch"
        ]

        manager.startAdvertising(advertisementData)
        print("BLE Watch: Started advertising")
    }
}

// MARK: - CBPeripheralManagerDelegate
extension BLEBeaconManager: CBPeripheralManagerDelegate {

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        DispatchQueue.main.async {
            switch peripheral.state {
            case .poweredOn:
                self.bluetoothState = "Powered On"
                self.startAdvertising()
            case .poweredOff:
                self.bluetoothState = "Powered Off"
                self.isAdvertising = false
            case .unauthorized:
                self.bluetoothState = "Unauthorized"
            case .unsupported:
                self.bluetoothState = "Unsupported"
            case .resetting:
                self.bluetoothState = "Resetting"
            case .unknown:
                self.bluetoothState = "Unknown"
            @unknown default:
                self.bluetoothState = "Unknown"
            }
            print("BLE Watch: State = \(self.bluetoothState)")
        }
    }

    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        DispatchQueue.main.async {
            if let error = error {
                print("BLE Watch: Failed - \(error.localizedDescription)")
                self.isAdvertising = false
            } else {
                print("BLE Watch: Advertising successfully")
                self.isAdvertising = true
            }
        }
    }
}
