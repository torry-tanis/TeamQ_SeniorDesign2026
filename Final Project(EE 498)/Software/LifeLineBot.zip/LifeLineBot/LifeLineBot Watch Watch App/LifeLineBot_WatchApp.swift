//
//  LifeLineBot_WatchApp.swift
//  LifeLineBot Watch Watch App
//
//  Created by Torryana Tanis
// fucntion: loads contentviw for watch
import SwiftUI

@main
struct LifeLineBot_Watch_Watch_AppApp: App {
    init() {
        // Initialize WCSession early to ensure iPhone connectivity is ready
        // This will also trigger BLE beacon on iPhone when connected
        _ = WatchConnectivityManager.shared

        // Note: BLE beacon is now handled by iPhone (no restricted entitlement needed)
        // Watch sends command to iPhone via WatchConnectivity
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
