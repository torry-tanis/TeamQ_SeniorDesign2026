//  ContentView
//
//  Created by Torryana Tanis
// fucntion: main screen for apple watch app
import SwiftUI
import Combine

// MARK: - Server Configuration
// Change this URL to your ngrok URL when using university WiFi
// Example: "https://abc123.ngrok-free.app"
// For local testing: "http://192.168.12.134:5000"
let serverBaseURL = "http://100.95.21.127:5000"

struct ContentView: View {
    @StateObject private var sensors = RealSensorDataSource()
    @StateObject private var sosManager = SOSManager()
    @ObservedObject private var connectivity = WatchConnectivityManager.shared

    // Overall motion intensity from accelerometer
    private var accelMagnitude: Double {
        let x = sensors.accelX
        let y = sensors.accelY
        let z = sensors.accelZ
        return sqrt(x * x + y * y + z * z)
    }

    // Risk level based on heart rate and motion
    // Thresholds are synced from iPhone and customizable by user/caregiver
    private var riskLevel: String {
        let hr = sensors.heartRateBPM
        let motion = accelMagnitude
        let settings = connectivity.thresholdSettings

        // HIGH RISK conditions
        // - Significant tachycardia (HR > highHRUpper)
        // - Severe bradycardia (HR < highHRLower)
        // - High impact motion (> highMotion) - likely fall
        if hr > settings.highHRUpper || hr < settings.highHRLower || motion > settings.highMotion {
            return "HIGH"
        }
        // ELEVATED RISK conditions
        // - Mild tachycardia (HR > elevatedHRUpper)
        // - Mild bradycardia (HR < elevatedHRLower)
        // - Moderate impact (> elevatedMotion)
        else if hr > settings.elevatedHRUpper || hr < settings.elevatedHRLower || motion > settings.elevatedMotion {
            return "ELEVATED"
        }
        // NORMAL: HR within normal range, motion within daily activity range
        else {
            return "NORMAL"
        }
    }

    // color for the risk label
    private var riskColor: Color {
        switch riskLevel {
        case "HIGH":
            return .red
        case "ELEVATED":
            return .yellow
        default:
            return .green
        }
    }

    // Short risk label for compact display
    private var riskShortLabel: String {
        switch riskLevel {
        case "HIGH": return "HIGH"
        case "ELEVATED": return "MED"
        default: return "OK"
        }
    }

    var body: some View {
        Group {
            if sosManager.sosReceived {
                // Full-screen SOS Received view
                SOSReceivedView(sosManager: sosManager)
            } else {
                // Compact layout for watch screen
                VStack(spacing: 4) {
                    // Header
                    HStack {
                        Text("LifeLineBot")
                            .font(.system(size: 14, weight: .semibold))
                        Circle()
                            .fill(sensors.isAuthorized ? .green : .orange)
                            .frame(width: 6, height: 6)
                    }
                    .padding(.top, 2)

                    // Stats in 2x2 grid
                    HStack(spacing: 12) {
                        // Left column: Risk + Heart
                        VStack(spacing: 6) {
                            // Risk indicator
                            Text(riskShortLabel)
                                .font(.system(size: 18, weight: .bold))
                                .foregroundStyle(riskColor)

                            // Heart rate
                            HStack(spacing: 2) {
                                Image(systemName: "heart.fill")
                                    .font(.system(size: 10))
                                    .foregroundStyle(.red)
                                Text("\(sensors.heartRateBPM)")
                                    .font(.system(size: 14, weight: .medium))
                            }
                        }

                        // Right column: Motion
                        VStack(spacing: 6) {
                            Text(String(format: "%.1f", accelMagnitude))
                                .font(.system(size: 18, weight: .bold))
                            Text("g")
                                .font(.system(size: 12))
                                .foregroundStyle(.gray)
                        }
                    }
                    .padding(.vertical, 4)

                    // SOS Button - large and prominent
                    SOSButtonView(sosManager: sosManager)
                        .padding(.bottom, 4)
                }
                .padding(.horizontal, 8)
            }
        }
        // Start real sensor collection when view appears
        .onAppear {
            sensors.start()
        }
        // Stop sensor collection when view closes
        .onDisappear {
            sensors.stop()
        }
    }
}

// MARK: - SOS Button View
struct SOSButtonView: View {
    @ObservedObject var sosManager: SOSManager

    var body: some View {
        VStack(spacing: 2) {
            Button(action: {
                sosManager.sendSOS()
            }) {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text("SOS")
                        .fontWeight(.bold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent)
            .tint(sosManager.buttonColor)
            .disabled(sosManager.isSending)

            // Status feedback
            if !sosManager.statusMessage.isEmpty {
                Text(sosManager.statusMessage)
                    .font(.system(size: 10))
                    .foregroundStyle(sosManager.statusColor)
            }
        }
    }
}

// MARK: - SOS Received View
struct SOSReceivedView: View {
    @ObservedObject var sosManager: SOSManager

    var body: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 50))
                .foregroundStyle(.green)

            Text("SOS RECEIVED")
                .font(.title3)
                .fontWeight(.bold)
                .foregroundStyle(.green)

            Text("Help is on the way")
                .font(.caption)
                .foregroundStyle(.gray)

            Spacer()

            Button(action: {
                sosManager.reset()
            }) {
                Text("Dismiss")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
            }
            .buttonStyle(.bordered)
        }
        .padding()
    }
}

// MARK: - SOS Manager
class SOSManager: ObservableObject {
    @Published var isSending = false
    @Published var statusMessage = ""
    @Published var lastResult: SOSResult = .idle
    @Published var sosReceived = false

    enum SOSResult {
        case idle
        case success
        case failure
    }

    var buttonColor: Color {
        switch lastResult {
        case .idle:
            return .red
        case .success:
            return .green
        case .failure:
            return .orange
        }
    }

    var statusColor: Color {
        switch lastResult {
        case .idle:
            return .gray
        case .success:
            return .green
        case .failure:
            return .red
        }
    }

    func sendSOS() {
        guard !isSending else { return }

        isSending = true
        statusMessage = "Sending..."
        lastResult = .idle

        // Try iPhone relay first (required for Tailscale since watch can't run it)
        // Falls back to direct HTTP if iPhone unreachable
        if WatchConnectivityManager.shared.isPhoneReachable {
            sendSOSViaRelay()
        } else {
            // Fallback to direct HTTP (only works if watch is on same network)
            sendSOSDirect()
        }
    }

    /// Send SOS via iPhone relay (uses Tailscale on iPhone)
    private func sendSOSViaRelay() {
        statusMessage = "Via iPhone..."

        WatchConnectivityManager.shared.sendSOSViaPhone { [weak self] success, message in
            self?.isSending = false

            if success {
                self?.statusMessage = "SOS Sent!"
                self?.lastResult = .success
                self?.sosReceived = true
            } else {
                // iPhone relay failed, try direct as fallback
                print("Relay failed: \(message), trying direct...")
                self?.sendSOSDirect()
            }
        }
    }

    /// Send SOS directly from watch (requires watch on same network as Pi)
    private func sendSOSDirect() {
        statusMessage = "Direct..."

        guard let url = URL(string: "\(serverBaseURL)/sos") else {
            statusMessage = "Invalid URL"
            lastResult = .failure
            isSending = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 10

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isSending = false

                if let error = error {
                    self?.statusMessage = "Failed: \(error.localizedDescription)"
                    self?.lastResult = .failure
                    return
                }

                if let httpResponse = response as? HTTPURLResponse,
                   (200...299).contains(httpResponse.statusCode) {
                    self?.statusMessage = "SOS Sent!"
                    self?.lastResult = .success
                    self?.sosReceived = true
                } else {
                    self?.statusMessage = "Server Error"
                    self?.lastResult = .failure
                }
            }
        }.resume()
    }

    func reset() {
        sosReceived = false
        statusMessage = ""
        lastResult = .idle
    }
}

#Preview {
    ContentView()
}

