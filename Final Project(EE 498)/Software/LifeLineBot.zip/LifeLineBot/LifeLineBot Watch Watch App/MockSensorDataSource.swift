//
//  MockSensorDataSource.swift
//  Created by Torryana Tanis
// fucntion: creates mock sensor data
import Foundation
import Combine

/// Simulated sensor data for when we don't have a real Apple Watch yet.
/// Later: replace the internals with real HealthKit + CoreMotion reads
final class MockSensorDataSource: ObservableObject {

    // sensor values
    @Published var heartRateBPM: Int = 75
    @Published var accelX: Double = 0.0
    @Published var accelY: Double = 0.0
    @Published var accelZ: Double = -1.0

    private var timer: Timer?
    private let queue = DispatchQueue(label: "MockSensorQueue")

    /// generating mock data
    func start() {
        stop()

        // Update 10 times per second
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.generateSample()
        }
    }

    /// Stop generating data
    func stop() {
        timer?.invalidate()
        timer = nil
    }

    private func generateSample() {
        queue.async { [weak self] in
            guard let self else { return }

            // Mcok heart rate
            let hrChange = Int.random(in: -2...2)
            var newHR = self.heartRateBPM + hrChange
            newHR = max(55, min(120, newHR)) // range between 55–120
            let hrFinal = newHR

            // Mock accelerometer
            let noiseRange = -0.15...0.15
            let newX = Double.random(in: noiseRange)
            let newY = Double.random(in: noiseRange)
            let newZ = -1.0 + Double.random(in: noiseRange)

            DispatchQueue.main.async {
                self.heartRateBPM = hrFinal
                self.accelX = newX
                self.accelY = newY
                self.accelZ = newZ
                
                //sends to iphone
                WatchConnectivityManager.shared.sendSensorSnapshot(
                               heartRate: hrFinal,
                               accelX: newX,
                               accelY: newY,
                               accelZ: newZ
                           )
            }
        }
    }

    deinit {
        stop()
    }
}

