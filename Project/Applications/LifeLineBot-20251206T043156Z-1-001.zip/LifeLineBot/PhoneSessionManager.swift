//
//  PhoneSessionManager.swift
//  LifeLineBot
//
//  Created by Torryana Tanis on 11/17/25.
//  fucntion: manages all communciation ffrom watch
import Foundation
import WatchConnectivity
import Combine

/// Receives sensor snapshots from the Apple Watch and sends them to the iphone's IU
final class PhoneSessionManager: NSObject, WCSessionDelegate, ObservableObject {
    
    static let shared = PhoneSessionManager()
    //waits for messages from watch
    private override init() {
        super.init()
        activateSession()
    }
    //published properties that ui observes and updates
    @Published var lastHeartRate: Int = 0
    @Published var lastAccelX: Double = 0
    @Published var lastAccelY: Double = 0
    @Published var lastAccelZ: Double = 0
    @Published var lastUpdate: Date? = nil
    
    //acess the default WCSession
    private var session: WCSession? {
        WCSession.isSupported() ? WCSession.default : nil
    }

    private func activateSession() {
        guard let session = session else { return }
        session.delegate = self
        session.activate()
    }

    // MARK: - WCSessionDelegate
    //alerts if connection with watch is ready
    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        if let error = error {
            print("iPhone WCSession activation error: \(error.localizedDescription)")
        } else {
            print("iPhone WCSession activation state: \(activationState.rawValue)")
        }
    }
    //required
    func sessionDidBecomeInactive(_ session: WCSession) { }
    func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }
    //extracts sensor values and updates publisjed varibles
    func session(_ session: WCSession,
                 didReceiveMessage message: [String : Any]) {
        guard let type = message["type"] as? String,
              type == "sensorSnapshot" else { return }
        //read sensor vlaues
        let hr = message["heartRate"] as? Int ?? 0
        let ax = message["accelX"] as? Double ?? 0
        let ay = message["accelY"] as? Double ?? 0
        let az = message["accelZ"] as? Double ?? 0
        //updates UI immediately
        DispatchQueue.main.async {
            self.lastHeartRate = hr
            self.lastAccelX = ax
            self.lastAccelY = ay
            self.lastAccelZ = az
            self.lastUpdate = Date()
        }
    }
}

