//  LifeLineBotApp
//
//  Created by Torryana Tanis 
//  Function: displays live data from watch
import SwiftUI

struct ContentView: View {
    //pulls in shared seesion manger that recieves daa from watch
    @EnvironmentObject var session: PhoneSessionManager
    //computes accel. magnitude
    private var accelMagnitude: Double {
        let x = session.lastAccelX
        let y = session.lastAccelY
        let z = session.lastAccelZ
        return sqrt(x * x + y * y + z * z)
    }
    //displays status message
    private var statusText: String {
        guard session.lastUpdate != nil else {
            return "Waiting for data from LifeLineBot Watch..."
        }
        return "Receiving live data from LifeLineBot Watch."
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                //header of dashboard
                Text("LifeLineBot iPhone")
                    .font(.title2)
                    .fontWeight(.semibold)
                //shows whether the watch is sending data
                Text(statusText)
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .multilineTextAlignment(.center)

                Divider()
                //display the latest vitals and motion data recieved
                VStack(alignment: .leading, spacing: 8) {
                    Text("Latest Heart Rate: \(session.lastHeartRate) bpm")
                        .font(.headline)

                    Text(String(format: "Accel |a|: %.2f g", accelMagnitude))
                        .font(.subheadline)
                    //raw accel. readings
                    Text(String(format: "X: %.2f   Y: %.2f   Z: %.2f",
                                session.lastAccelX,
                                session.lastAccelY,
                                session.lastAccelZ))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("Stroke Guardian")
        }
    }
}

#Preview {
    //preview with phone session manger so UI can work properly 
    ContentView()
        .environmentObject(PhoneSessionManager.shared)
}

