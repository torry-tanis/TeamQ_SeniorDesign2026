//  Content View
//
//  Created by Torryana Tanis
//  function: initalize comuuncation manager and loads to dashboard
import SwiftUI

@main
struct LifeLineBotApp: App {
    //waits for incoming datd from watch
    @StateObject private var phoneSession = PhoneSessionManager.shared

    var body: some Scene {
        WindowGroup {
            //loads content view to session manager
            ContentView()
                .environmentObject(phoneSession)
        }
    }
}

